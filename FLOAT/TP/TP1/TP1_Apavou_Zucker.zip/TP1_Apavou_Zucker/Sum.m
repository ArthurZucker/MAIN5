function res = Sum(p)
n=length(p);
o = 0;
for i = 1:n
    o = o + p(i);
res = o;
end     