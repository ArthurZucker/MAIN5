function [x,y]=FastTwoSum( a,b)
x =  a+b;
y = (a-x)+b;
end